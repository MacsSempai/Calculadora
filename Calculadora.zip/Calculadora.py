from tkinter import *

def binario_decimal(numero):
    try:
        numerobinario = int(numero)
        binario = [int(x) for x in str(numerobinario)]
        binario.reverse()
        lista=[]
        for x in range(len(binario)):
            indice=x
            op=binario[x]*(2**indice)
            lista.append(op)
        total= sum(lista)
        return (total)
    except:
        calculo.set(0)
        calculo2.set(0)
        Decimal ["state"] = DISABLED

def decimal_binario(numero):   ## Función de conversión decimal a binario
    try:    
        decimal = int(numero)
        binario = ''  ## Variable vacía que contendrá el número binario
        while decimal // 2 != 0:  ## mientras la division en 2 del número decimal sea distinta de 0
            binario = str(decimal % 2) + binario  ## A la variable binario se le añadirá el sobrante de la divison del decimal
            decimal = decimal // 2   ## Y el número decimal se dividirá en 2
        numbinaio = str(decimal) + binario
        return (numbinaio)
    except:
        calculo.set(0)
        calculo2.set(0)
        Binario ["state"] = DISABLED

def octal_decimal(numero):
    decimal = 0
    posicion = 0
    octal = (numero)
    octal = octal[::-1]
    for digito in octal:
        valor_entero = int(digito)
        numero_elevado = int(8 ** posicion)
        equivalencia = int(numero_elevado * valor_entero)
        decimal += equivalencia
        posicion += 1
    return (decimal)


def decimal_octal(numero):
    try:
        octal = ""
        decimal = int(numero)
        while decimal > 0:
            residuo = decimal % 8
            octal = str(residuo) + octal
            decimal = int(decimal / 8)
        return (octal) 
    except:
        calculo.set(0)
        calculo2.set(0)
        Decimal ["state"] = DISABLED
        

def hexa_decimal(numero): ## Función para convertir Hexadecimal a Decimal
    try:
        listahexa= list(str(numero))  ## Convertimos el número decimal a lista
        listahexa.reverse()  ## Volteamos la lista debido a que el número se recorre de atrás hacia adelante
        for x in range(len(listahexa)): ## Este for reemplaza todos los digitos de letras a número(En formato str)
            if listahexa[x]=="A":
                listahexa[x]="10"
            elif listahexa[x]=="B":
                listahexa[x]="11"
            elif listahexa[x]=="C":
                listahexa[x]="12"
            elif listahexa[x]=="D":
                listahexa[x]="13"
            elif listahexa[x]=="E":
                listahexa[x]="14"
            elif listahexa[x]=="F":
                listahexa[x]="15"
        listahexa = [int(i) for i in listahexa] ## Este apartado convierte los str a valores int
        lista=[] ## Lista para la suma final
        for x in range(len(listahexa)): ## Este for reliza la operación de conversión
            indice=x
            op=listahexa[x]*(16**indice) ## El número se multiplica por 16 elevado a su indice dentro del número
            lista.append(op) ## Se añade a la lista
        total= sum(lista) ## Se suman todos los valores
        return (total)    
    except:
        calculo.set(0)
        calculo2.set(0) 
        Decimal ["state"] = DISABLED

def decimal_hexa(numero):
    def obtener_caracter_hexadecimal(valor): ## Funcion para poner equivalencias de números, estas son puestas en un diccionario
        valor = str(valor) ## Convertimos la variable valor a un string
        equivalencias = {
            "10": "A",
            "11": "B",
            "12": "C",            ## Diccionario con numeros y sus equivalencias en forma de tuplas
            "13": "D",
            "14": "E",
            "15": "F",
        }
        if valor in equivalencias:      ## Si valor pertenece al diccionario equivalencias
            return equivalencias[valor]   ## Retorna el valor dentro del diccionario equivalencias
        else:               ## Sino
            return valor ## Devuelve solamente el valor

    def decimal_a_hexadecimal(decimal):  ## Función para la conversión de decimal a Hexadecimal
        hexadecimal = ""    ## Variable vacía
        while decimal > 0:    ## Mientras el número decimal sea mayor a 0, esto hara que el programa no funcione con números negativos
            residuo = decimal % 16  ## Residuo es el sobrante de la división del número decimal entre 16
            verdadero_caracter = obtener_caracter_hexadecimal(residuo)  ## Verdadero caracter reemplaza a los caracteres con su valor en hexadecimal
            hexadecimal = verdadero_caracter + hexadecimal ## El número Hexadecimal es igual a el verdadero caracter mas el número el número hexadecimal
            decimal = int(decimal / 16) ## Se divide el decimal entre 16 (Decimal convertido a int)
        return hexadecimal  ## Retorna el número decimal ya transformado

    try:
        decimal = int(numero)
        hexadecimal = decimal_a_hexadecimal(decimal)
        return (hexadecimal)
    except:
        calculo.set(0) 
        calculo2.set(0) 
        Hexadecimal ["state"] = DISABLED

    
def switchdecimal():
    try:
        if Octal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = (calculo.get())
                calculo.set(octal_decimal(numero1))
            if datos2 ["state"] == NORMAL:
                numero2 = (calculo2.get())
                calculo2.set(octal_decimal(numero2))

        if Binario ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                calculo.set(binario_decimal(numero1))
            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                calculo2.set(binario_decimal(numero2))

        if Hexadecimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = str(calculo.get())
                calculo.set(hexa_decimal(numero1))
            if datos2 ["state"] == NORMAL:
                numero2 = str(calculo2.get())
                calculo2.set(hexa_decimal(numero2))
    except:
        calculo.set(0) 
        calculo2.set(0) 

    Binario ["state"] = NORMAL
    Hexadecimal ["state"] = NORMAL
    Octal ["state"] = NORMAL    
    Decimal ["state"] = DISABLED
    botonA ["state"] = DISABLED
    botonB ["state"] = DISABLED
    botonC ["state"] = DISABLED
    botonD ["state"] = DISABLED
    botonE ["state"] = DISABLED
    botonF ["state"] = DISABLED
    boton2 ["state"] = NORMAL
    boton3 ["state"] = NORMAL
    boton4 ["state"] = NORMAL
    boton5 ["state"] = NORMAL
    boton6 ["state"] = NORMAL
    boton7 ["state"] = NORMAL
    boton8 ["state"] = NORMAL
    boton9 ["state"] = NORMAL
    
def switchoctal():
    try:
        if Decimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                calculo.set(decimal_octal(numero1))

            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                calculo2.set(decimal_octal(numero2))      

        if Hexadecimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = str(calculo.get())
                decimal1 = hexa_decimal(numero1)
                octal = decimal_octal(decimal1)
                calculo.set(octal)

            if datos2 ["state"] == NORMAL:
                numero2 = str(calculo.get())
                decimal2 = hexa_decimal(numero2)
                octal = decimal_octal(decimal2)
                calculo2.set(octal)

        if Binario ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                decimal1 = binario_decimal(numero1)
                octal = decimal_octal(decimal1)
                calculo.set(octal)
            
            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                decimal2 = binario_decimal(numero2)
                octal = decimal_octal(decimal2)
                calculo2.set(octal)
    except:
        calculo.set(0) 
        calculo2.set(0) 

    Hexadecimal ["state"] = NORMAL
    Binario ["state"] = NORMAL
    Decimal ["state"] = NORMAL
    Octal ["state"] = DISABLED    
    botonA ["state"] = DISABLED
    botonB ["state"] = DISABLED
    botonC ["state"] = DISABLED
    botonD ["state"] = DISABLED
    botonE ["state"] = DISABLED
    botonF ["state"] = DISABLED
    boton2 ["state"] = NORMAL
    boton3 ["state"] = NORMAL
    boton4 ["state"] = NORMAL
    boton5 ["state"] = NORMAL
    boton6 ["state"] = NORMAL
    boton7 ["state"] = NORMAL
    boton8 ["state"] = DISABLED
    boton9 ["state"] = DISABLED

def switchhexadecimal():
    try:
        if Decimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                calculo.set(decimal_hexa(numero1))

            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                calculo2.set(decimal_hexa(numero2))

        if Binario ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                decimal1 = binario_decimal(numero1)
                hexa = decimal_hexa(decimal1)
                calculo.set(hexa)
            
            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                decimal2 = binario_decimal(numero2)
                hexa = decimal_hexa(decimal2)
                calculo2.set(hexa)

        if Octal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = (calculo.get())
                decimal1 = octal_decimal(numero1)
                hexa = decimal_hexa(decimal1)
                calculo.set(hexa)
            
            if datos2 ["state"] == NORMAL:
                numero2 = (calculo2.get())
                decimal2 = octal_decimal(numero2)
                hexa = decimal_hexa(decimal2)
                calculo2.set(hexa)
    except:
        calculo.set(0) 
        calculo2.set(0) 

    Decimal ["state"] = NORMAL
    Octal ["state"] = NORMAL
    Hexadecimal ["state"] = DISABLED
    Binario ["state"] = NORMAL
    botonA ["state"] = NORMAL
    botonB ["state"] = NORMAL
    botonC ["state"] = NORMAL
    botonD ["state"] = NORMAL
    botonE ["state"] = NORMAL
    botonF ["state"] = NORMAL
    boton2 ["state"] = NORMAL
    boton3 ["state"] = NORMAL
    boton4 ["state"] = NORMAL
    boton5 ["state"] = NORMAL
    boton6 ["state"] = NORMAL
    boton7 ["state"] = NORMAL
    boton8 ["state"] = NORMAL
    boton9 ["state"] = NORMAL
    
def switchbinario():
    try:
        if Decimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = int(calculo.get())
                calculo.set(decimal_binario(numero1))

            if datos2 ["state"] == NORMAL:
                numero2 = int(calculo2.get())
                calculo2.set(decimal_binario(numero2))

        if Octal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = (calculo.get())
                decimal1 = octal_decimal(numero1)
                hexa = decimal_binario(decimal1)
                calculo.set(hexa)
            
            if datos2 ["state"] == NORMAL:
                numero2 = (calculo2.get())
                decimal2 = octal_decimal(numero2)
                hexa = decimal_binario(decimal2)
                calculo2.set(hexa)

        if Hexadecimal ["state"] == DISABLED:
            if datos ["state"] == NORMAL:
                numero1 = str(calculo.get())
                decimal1 = hexa_decimal(numero1)
                hexa = decimal_binario(decimal1)
                calculo.set(hexa)
            
            if datos2 ["state"] == NORMAL:
                numero2 = str(calculo2.get())
                decimal2 = hexa_decimal(numero2)
                hexa = decimal_binario(decimal2)
                calculo2.set(hexa)
    except:
        calculo.set(0) 
        calculo2.set(0) 

    Decimal ["state"] = NORMAL
    Octal ["state"] = NORMAL
    Hexadecimal ["state"] = NORMAL
    Binario ["state"] = DISABLED
    botonA ["state"] = DISABLED
    botonB ["state"] = DISABLED
    botonC ["state"] = DISABLED
    botonD ["state"] = DISABLED
    botonE ["state"] = DISABLED
    botonF ["state"] = DISABLED
    boton2 ["state"] = DISABLED
    boton3 ["state"] = DISABLED
    boton4 ["state"] = DISABLED
    boton5 ["state"] = DISABLED
    boton6 ["state"] = DISABLED
    boton7 ["state"] = DISABLED
    boton8 ["state"] = DISABLED
    boton9 ["state"] = DISABLED


def digito(num):
    if datos ["state"] == NORMAL:
        boton = (calculo.get())
        boton = boton + str(num)
        calculo.set(boton)
        datos.icursor(END)
    if datos2 ["state"] == NORMAL:
        boton = (calculo2.get())
        boton = boton + str(num)
        calculo2.set(boton)
        datos2.icursor(END)

def igual():
    datos ["state"] = DISABLED
    datos2 ["state"] = DISABLED
    resultado ["state"] = NORMAL
    try:
        operacion = simbolo.get()
        numero1 = (calculo.get())
        numero2 = (calculo2.get())
        if Decimal ["state"] == DISABLED:
            boton = (numero1 + operacion + numero2)
            total = str(eval(boton)) 

        if Binario ["state"] == DISABLED:
            decimal1 = str(binario_decimal(numero1))
            decimal2 = str(binario_decimal(numero2))
            boton = (decimal1 + operacion + decimal2)
            resultado_Decimal = str(eval(boton)) 
            total = decimal_binario(resultado_Decimal)           

        if Octal ["state"] == DISABLED:
            decimal1 = str(octal_decimal(numero1))
            decimal2 = str(octal_decimal(numero2))
            boton = (decimal1 + operacion + decimal2)
            total = str(eval(boton))  
            total = decimal_octal(total)         

        if Hexadecimal ["state"] == DISABLED:
            decimal1 = str(hexa_decimal(numero1))
            decimal2 = str(hexa_decimal(numero2))
            boton = (decimal1 + operacion + decimal2)
            total = str(eval(boton))
            total = decimal_hexa(total) 
  
        resultados.set(total)
        boton = ""
    except: resultados.set(" ERROR ")

def operadores(op):
    datos ["state"] = DISABLED
    datos2 ["state"] = NORMAL
    operacion = str(op)
    simbolo.set(operacion)
    return operacion

def limpiar():
    datos ["state"] = NORMAL
    datos2 ["state"] = DISABLED
    resultado ["state"] = DISABLED
    simbolo.set("")
    calculo.set("")
    calculo2.set("")
    resultados.set("")

if __name__ == "__main__":
    ventana = Tk()
    ventana.title("Calculadora")
    ventana.resizable(0,0)
    ventana.iconbitmap("Icon.ico")
    calculo = StringVar()
    calculo2 = StringVar()
    simbolo = StringVar()
    resultados = StringVar()

    datos = Entry(ventana, width=13,font=("Helvetica",15), justify=RIGHT, textvariable=calculo, state=NORMAL)
    datos.grid(columnspan=3, row=0, column=0, padx=25, pady=3)
    datos2 = Entry(ventana, width=13,font=("Helvetica",15), justify=RIGHT, textvariable=calculo2, state=DISABLED)
    datos2.grid(columnspan=5, row=0, column=3, padx=24, pady=3)
    resultado = Entry(ventana, width=13,font=("Helvetica",14), justify=RIGHT, textvariable=resultados, state=DISABLED)
    resultado.grid(columnspan=4, row=1, column=1, padx=24, pady=3)

    operador = Label(ventana,text=" ", width=1,font=("Helvetica",15), textvariable=simbolo)
    operador.grid(columnspan=2, row=0, column=2, padx=24, pady=3)

    Decimal = Button(ventana, text='Decimal', fg='black', bg='white',
                    command=switchdecimal,width=11, height=1, font=("Helvetica",15), state=DISABLED)
    Decimal.grid(row=2, column=0, columnspan=2)

    Binario = Button(ventana, text='binario', fg='black', bg='white',
                    command=switchbinario ,width=11, height=1, font=("Helvetica",15))
    Binario.grid(row=3, column=0, columnspan=2)

    Octal = Button(ventana, text='Octal', fg='black', bg='white',
                    command=switchoctal,width=11, height=1, font=("Helvetica",15))
    Octal.grid(row=4, column=0, columnspan=2)

    Hexadecimal = Button(ventana, text='Hexadecimal', fg='black', bg='white',
                    command=switchhexadecimal,width=11, height=1, font=("Helvetica",15))
    Hexadecimal.grid(row=5, column=0, columnspan=2)

    boton1 = Button(ventana, text=' 1 ', fg='black', bg='white',
                     command=lambda: digito(1), width=5, height=1, font=("Helvetica",15))
    boton1.grid(row=4, column=3)

    boton2 = Button(ventana, text=' 2 ', fg='black', bg='white',
                     command=lambda: digito(2), width=5, height=1, font=("Helvetica",15))
    boton2.grid(row=4, column=4)

    boton3 = Button(ventana, text=' 3 ', fg='black', bg='white',
                     command=lambda: digito(3), width=5, height=1, font=("Helvetica",15))
    boton3.grid(row=4, column=5)

    boton4 = Button(ventana, text=' 4 ', fg='black', bg='white',
                     command=lambda: digito(4), width=5, height=1, font=("Helvetica",15))
    boton4.grid(row=3, column=3)

    boton5 = Button(ventana, text=' 5 ', fg='black', bg='white',
                     command=lambda: digito(5), width=5, height=1, font=("Helvetica",15))
    boton5.grid(row=3, column=4)

    boton6 = Button(ventana, text=' 6 ', fg='black', bg='white',
                     command=lambda: digito(6), width=5, height=1, font=("Helvetica",15))
    boton6.grid(row=3, column=5)

    boton7 = Button(ventana, text=' 7 ', fg='black', bg='white',
                     command=lambda: digito(7), width=5, height=1, font=("Helvetica",15))
    boton7.grid(row=2, column=3)

    boton8 = Button(ventana, text=' 8 ', fg='black', bg='white',
                     command=lambda: digito(8), width=5, height=1, font=("Helvetica",15))
    boton8.grid(row=2, column=4)

    boton9 = Button(ventana, text=' 9 ', fg='black', bg='white',
                     command=lambda: digito(9), width=5, height=1, font=("Helvetica",15))
    boton9.grid(row=2, column=5)

    boton0 = Button(ventana, text=' 0 ', fg='black', bg='white',
                     command=lambda: digito(0), width=5, height=1, font=("Helvetica",15))
    boton0.grid(row=5, column=4)

    botonA = Button(ventana, text=' A ', fg='black', bg='white',
                     command=lambda: digito("A"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonA.grid(row=6, column=0)

    botonB = Button(ventana, text=' B ', fg='black', bg='white',
                     command=lambda: digito("B"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonB.grid(row=6, column=1)

    botonC = Button(ventana, text=' C ', fg='black', bg='white',
                     command=lambda: digito("C"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonC.grid(row=6, column=2)

    botonD = Button(ventana, text=' D ', fg='black', bg='white',
                     command=lambda: digito("D"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonD.grid(row=6, column=3)

    botonE = Button(ventana, text=' E ', fg='black', bg='white',
                     command=lambda: digito("E"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonE.grid(row=6, column=4)

    botonF = Button(ventana, text=' F ', fg='black', bg='white',
                     command=lambda: digito("F"), width=5, height=1, font=("Helvetica",15), state=DISABLED)
    botonF.grid(row=6, column=5)

    suma = Button(ventana, text=' + ', fg='black', bg='white',
                  command=lambda: operadores("+"), width=5, height=1, font=("Helvetica",15))
    suma.grid(row=5, column=2)

    resta = Button(ventana, text=' - ', fg='black', bg='white',
                   command=lambda: operadores("-"), width=5, height=1, font=("Helvetica",15))
    resta.grid(row=4, column=2)

    multiplica = Button(ventana, text=' * ', fg='black', bg='white',
                      command=lambda: operadores("*"), width=5, height=1, font=("Helvetica",15))
    multiplica.grid(row=3, column=2)

    divide = Button(ventana, text=' / ', fg='black', bg='white',
                    command=lambda: operadores("/"), width=5, height=1, font=("Helvetica",15))
    divide.grid(row=2, column=2)

    limpiador = Button(ventana, text=U'\u232B', fg='black', bg='white',
                   command=limpiar, width=5, height=1, font=("Helvetica",15))
    limpiador.grid(row=5, column=3)

    igualdad = Button(ventana, text=' = ', fg='black', bg='white',
                   command=igual, width=5, height=1, font=("Helvetica",15))
    igualdad.grid(row=5, column=5)





    ventana.mainloop()



